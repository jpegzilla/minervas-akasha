self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "19ad2a43fa701e976d2296121e9dd5f3",
    "url": "./69dcbb1ec75d13301894.worker.js"
  },
  {
    "revision": "f124a00a49e9f6acad49e7f190df5f4b",
    "url": "./69dcbb1ec75d13301894.worker.js.LICENSE.txt"
  },
  {
    "revision": "f3d478f1962b1ac0f985d7b7f075d29f",
    "url": "./6c56a65d4b134de0e785.worker.js"
  },
  {
    "revision": "f1ecf436e87fb18c37414eb1a6d1b86d",
    "url": "./b06ab248aef1c5cf8e4f.worker.js"
  },
  {
    "revision": "e0bfca444fc829fc15a91c00d3651b91",
    "url": "./index.html"
  },
  {
    "revision": "ab8110880d83a258a33c",
    "url": "./static/css/main.5e9e620d.chunk.css"
  },
  {
    "revision": "61079b43ea1527521fd0",
    "url": "./static/js/2.3a4ec2b3.chunk.js"
  },
  {
    "revision": "ea36af307122ee03e60d9f4dce397dcf",
    "url": "./static/js/2.3a4ec2b3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ab8110880d83a258a33c",
    "url": "./static/js/main.cc59ce08.chunk.js"
  },
  {
    "revision": "e115b72f27a384be4316",
    "url": "./static/js/runtime-main.27e909c2.js"
  },
  {
    "revision": "4da09fe9479924bddf8e37f7a45ccf2e",
    "url": "./static/media/LigaProggyCleanTTSZ.4da09fe9.ttf"
  },
  {
    "revision": "5d3bcded6902a006ee0b2603fee5864f",
    "url": "./static/media/PxPlus_IBM_EGA9.5d3bcded.ttf"
  },
  {
    "revision": "bba89c0d2f9247170fddad86b83a02fa",
    "url": "./static/media/a.bba89c0d.wav"
  },
  {
    "revision": "a842919e423ddd000ee12337b3752228",
    "url": "./static/media/b.a842919e.wav"
  },
  {
    "revision": "b170effc88bf0f8f78fa7ab47167b37e",
    "url": "./static/media/binding-dark.b170effc.png"
  },
  {
    "revision": "15e14075194e528f9c8f4e893a0c6385",
    "url": "./static/media/click-noise.15e14075.wav"
  },
  {
    "revision": "8f8a8b98c655870f6b0502069cc630bc",
    "url": "./static/media/click-short.8f8a8b98.wav"
  },
  {
    "revision": "01959890e965117dd144a03ffc1638fb",
    "url": "./static/media/close-one.01959890.wav"
  },
  {
    "revision": "9f9695dd33ce7458d21e8cd1b2ce7a7e",
    "url": "./static/media/d.9f9695dd.wav"
  },
  {
    "revision": "5573fc7fc7ec34eb7fb6be37b17a57b4",
    "url": "./static/media/e.5573fc7f.wav"
  },
  {
    "revision": "6555bc0f357a5f6057727c1253140f73",
    "url": "./static/media/error-one.6555bc0f.wav"
  },
  {
    "revision": "33c6877cb9ebc26e8840155c6ac1fe69",
    "url": "./static/media/f.33c6877c.wav"
  },
  {
    "revision": "c0acd3e369798d4024a1f85b20dc3ddd",
    "url": "./static/media/g.c0acd3e3.wav"
  },
  {
    "revision": "1910080f713e0b1e1b5add5d6923c0d2",
    "url": "./static/media/i.1910080f.wav"
  },
  {
    "revision": "45e7d7f8794315c4837fe9f4d2130514",
    "url": "./static/media/intro.45e7d7f8.wav"
  },
  {
    "revision": "f9e1573096db928c1f6dc91192f470b5",
    "url": "./static/media/j.f9e15730.wav"
  },
  {
    "revision": "c4c16941414e9bf61b482447e12a9ec5",
    "url": "./static/media/k.c4c16941.wav"
  },
  {
    "revision": "7d3b4cf99c467f405b14b6fcce43b5ee",
    "url": "./static/media/keypress-one.7d3b4cf9.wav"
  },
  {
    "revision": "9b8c415e6dc444782e1725d90f09bc4e",
    "url": "./static/media/m.9b8c415e.wav"
  },
  {
    "revision": "7b2aa9126821f24e824104f949121711",
    "url": "./static/media/o.7b2aa912.wav"
  },
  {
    "revision": "95c5be3e1aa7cbe1fa9bab122ed5e0a5",
    "url": "./static/media/open-one.95c5be3e.wav"
  },
  {
    "revision": "4d97b1c7cfa684d432420ef1b5f8379a",
    "url": "./static/media/p.4d97b1c7.wav"
  },
  {
    "revision": "eb1e54c2b82ea86629618882ac5e708a",
    "url": "./static/media/r.eb1e54c2.wav"
  },
  {
    "revision": "bdccdbef1e80c8ac16410878d708b4c8",
    "url": "./static/media/s.bdccdbef.wav"
  },
  {
    "revision": "cfdd5db1f25ffa0161fca054166724eb",
    "url": "./static/media/silent.cfdd5db1.wav"
  },
  {
    "revision": "1f60eb064734e6045f0c443104709b3f",
    "url": "./static/media/sine-short.1f60eb06.wav"
  },
  {
    "revision": "e749041765f2e9bfebcdf114ceac19f3",
    "url": "./static/media/startup-two.e7490417.wav"
  },
  {
    "revision": "31bb6a55544cc60c80713b8d5c21870d",
    "url": "./static/media/success-dist.31bb6a55.wav"
  },
  {
    "revision": "8354675852e1358b3c72e7fd51ee93a7",
    "url": "./static/media/success-two.83546758.wav"
  },
  {
    "revision": "f5fe708914cc6291ac6a5cc074399e62",
    "url": "./static/media/t.f5fe7089.wav"
  },
  {
    "revision": "d275ba6bea605a30dc04184655a26028",
    "url": "./static/media/u.d275ba6b.wav"
  },
  {
    "revision": "f739bead3073ca003a3fb25948168e97",
    "url": "./static/media/v.f739bead.wav"
  },
  {
    "revision": "ce8e57ee202473188c2168c4e53f651c",
    "url": "./static/media/w.ce8e57ee.wav"
  },
  {
    "revision": "63d592037737726720cc846b7521b9e2",
    "url": "./static/media/warn-one.63d59203.wav"
  },
  {
    "revision": "f42bf3b2825cf3ba3420054646197c26",
    "url": "./static/media/y.f42bf3b2.wav"
  },
  {
    "revision": "730e76982dec656fcc5ad01e58ae78db",
    "url": "./static/media/z.730e7698.wav"
  }
]);